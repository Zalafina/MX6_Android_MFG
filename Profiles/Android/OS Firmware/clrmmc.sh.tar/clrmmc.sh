#!/bin/sh

# clear mmcblk0boot0 to zero (blocksize=1MB)
echo 0 > /sys/block/mmcblk0boot0/force_ro;
size_a=$(cat /sys/block/mmcblk0boot0/size);
let count_a=size_a/2048;
dd if=/dev/zero of=/dev/mmcblk0boot0 bs=1M count=$count_a;
echo 1 > /sys/block/mmcblk0boot0/force_ro;

# clear mmcblk0 to zero (blocksize=1MB)
size_b=$(cat /sys/block/mmcblk0/size);
let count_b=size_b/2048;
dd if=/dev/zero of=/dev/mmcblk0 bs=1M count=$count_b;